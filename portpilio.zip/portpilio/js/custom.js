$(document).ready(function() {
    
    "use strict";
   
  

    //back to top  button
        $(window).on('scroll',function() {
            if ($(this).scrollTop() > 200) {
                $('#scroll').fadeIn();
            } else {
                $('#scroll').fadeOut();
            }
        });
        $('#scroll').on('click',function() {
            $("html, .dddddd").animate({
                scrollTop: 0
            }, 1000);
            return false;
        });
    
    // 
    
       
    
    
//menu
	$(".hamburger").click(function()
    {
        $(".navigation").toggleClass("open") ;
    })
 //show code start
               
           $('.show').click(function(){
                   $('.menu').show({opacity:'1'});
                }); 
//show code start
            
//show code start
                $('.show').click(function(){
                   $('#full_contact').animate({right: '0'});
                }); 
    $('#hide').click(function(){
                   $('#full_contact').animate({right: '-100%'});
                });
//show code start
            
        var input = document.querySelector("#phone");
window.intlTelInput(input, {
  utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@14.0.3/build/js/utils.js",
});
            

})
